var nuevaTareaInput = document.getElementById("nuevaTarea");
var agregarbtn = document.getElementById("agregarbtn");
var listaTareas = document.getElementById("vistaTareas");

//Agregra evento al boton agregar al dar click
agregarbtn.addEventListener("click",function(){
    var textoTarea = nuevaTareaInput.value;
 

    if (textoTarea !== "") {
        var nuevaTarea = document.createElement("li");
        nuevaTarea.classList.add("Tarea");

        var spanTexto = document.createElement("span");
        spanTexto.textContent = textoTarea;
        nuevaTarea.appendChild(spanTexto);

        var divBotones = document.createElement("div");

        var eliminarbtn = document.createElement("button");
        eliminarbtn.classList.add("Eliminar");

        eliminarbtn.addEventListener("click", function(){
            listaTareas.removeChild(nuevaTarea);
        });

        var modificarbtn = document.createElement("button");
        modificarbtn.classList.add("modificarbtn");
        modificarbtn.textContent.textContent = "Modificar"

        modificarbtn.addEventListener("click" ,function(){
            

            if(modificarbtn.textContent === "Modificar"){
                modificarbtn.textContent = "text";
                inputModificacion.value = spanTexto.textContent;
                nuevaTarea.replaceChild(inputModificacion, spanTexto);

            }else{

                modificarbtn.textContent = "Modificar";

                var nuevotexto = nuevaTarea.firstChild.value;

                spanTexto.textContent = nuevotexto;
                nuevaTarea.replaceChild(spanTexto,nuevaTarea.firstChild.value);

            }
        });

        //anadir los botones div  de botones 

        divBotones.appendChild(modificarbtn);
        divBotones.appendChild(eliminarbtn);

        // anadir el div de botones a la tareas

        nuevaTarea.appendChild(divBotones);

       //anadir la nueva tarea a la lista de tareas 
        listaTareas.appendChild(nuevaTarea);

        nuevaTareaInput.value = "";
        
    }else{
        alert("no se puede agregar una tarea vacia ");
    }
})